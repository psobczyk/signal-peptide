#ifndef FBIMPL
	#define FBIMPL

	void FBImpl(int CensoringPara, int tauPara, int JPara,
			    int MPara, double dPara[], double pPara[], double piPara[], double pdfPara[],
			    double FPara[], double LPara[], double GPara[], double L1Para[], double NPara[], double NormPara[], 
			    double etaPara[], double xiPara[], int *err);

#endif


