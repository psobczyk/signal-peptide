#ifndef MATHE
	#define MATHE

	int ind (bool b) {if (b) return 1; else return 0; }

	int min(int a, int b) { return (a<b) ? a : b; }

#endif
