# Simulating a Hidden semi-Markov model:
demo(hsmm.sim)
# Estimating the parameters of a Hidden semi-Markov model:
demo(hsmm.est)
# Comparing local and global decoding:
demo(hsmm.dec)
