print.hsmm <- function(x, ...){
  print.default(x)
  }
